<template>
  <div id="app">
    <div id="mySheet" @scroll="handleScroll">
      <CustomExcel @scroll="handleScroll" :sheetData="sheetData" ref="luckySheet" :config="config" />
    </div>

    <div class="wrapper">
      <div class="option">
        <div>
          <label for="">
            表数量:
            <input type="number" min="1" max="10" v-model.number="sheet" />
          </label>
          <label for="">
            行数:
            <input type="number" min="1" max="5000" v-model.number="row" />
          </label>
          <label for="">
            列数:
            <input type="number" min="1" max="1000" v-model.number="col" />
          </label>
          <!-- <button @click="handleMock">mock数据</button> -->
        </div>
        <div>
          <label for="">
            每页数量:
            <input type="number" min="1" max="1000" v-model.number="pageSize" />
          </label>
          <label for="">
            当前页:
            <input type="number" min="1" max="1000" v-model.number="pageNum" />
          </label>

          <!-- <button @click="handlefirstPage">初始</button> -->
          <button @click="handleNextPage">下一页</button>
        </div>
        <button @click="renderSheet">一次性渲染</button>
        <button @click="batchesRender">分批渲染</button>
        <button @click="refresh">刷新</button>
        <button @click="getSheetData">保存数据</button>
        <button @click="toJson">转换成JSON</button>
        <button @click="exportExcel">导出excel</button>
        <button @click="clear">清空数据</button>
      </div>
      <div class="pannel">
        <input type="file" @change="handleFileChange" accept=".xlsx" name="导入excel" />

        <!-- <button class="cancel" @click="handleCancel">取消</button> -->


        <div v-if="excelData" :style="{height: '300px'}" @scroll="handleScroll">
          <h3>Excel 读取成功：</h3>
          <div>文件大小 {{(file.size/1024/1024).toFixed(2)}}M</div>
          <div>{{ excelData }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

  import CustomExcel from './components/cumstomExcel';
  import { getFormatterExcelData } from './components/cumstomExcel/action.js';
  import { mockData, excelJson } from './mock/mockData.js';
  import { mockGediData } from './mock/gediData.js'
  import { simpleData, simpleData1 } from './mock/simleData.js';
  import { getMockData, getPageData } from './mock/mock.js';


  export default {
    name: 'app',
    components: {
      CustomExcel,

    },
    data() {
      return {
        sheet: 1,
        row: 250,
        col: 10,
        pageSize: 5,
        pageNum: 1,
        msg: 'Welcome to Your Vue.js App',
        sheetOption: {
          title: 'hhh',
        },
        config: {},
        sheetData: [],
        excelData: null,
        file: null
      }
    },
    methods: {

      getOption() {
        const info = {
          name: "数字化部人员盘点.xlsx",
          creator: "徐达游",
          lastmodifiedby: "徐达游",
          createdTime: "2015-06-05T18:19:00Z",
          modifiedTime: "2023-08-17T08:34:39Z",
          company: "",
          appversion: "16.0300",
          row: this.row + 10,
          column: this.col
        }
        let data = null;
        if (this.sheetData && this.sheetData.sheets) {
          console.log('return sheetData', this.sheetData);
          data = this.sheetData;
          data.info = info;
          return data
        }
        let cellData = getMockData(this.row, this.col);
        data = {
          info,
          sheets: []
        };
        for (let i = 0; i < this.sheet; i++) {
          const item = {
            name: "Cell" + i, //工作表名称
            celldata: cellData, //初始化使用的单元格数据

          };
          data.sheets.push(item);
        }
        console.log('mockdata', data);
        return data

      },
      handleMock() {
        this.sheetData = null;
        let data = this.getOption()
        this.$refs.luckySheet.renderExcel(data)

      },

      handleNextPage() {
        this.batchesRender();
      },
      getSheetData() {
        const luckySheetComponent = this.$refs.luckySheet;
        console.log(luckySheetComponent.getInstance().getAllSheets());
        // this.testData = luckySheetComponent.getInstance().getAllSheets();
      },
      renderSheet() {
        this.$refs.luckySheet.renderExcel(this.getOption())

      },

      exportExcel() {
        this.$refs.luckySheet.exportExcel()
      },
      tableToExcel() {
        this.$refs.luckySheet.tableToExcel()
      },

      updataSheet() {
        this.sheetData = getMockData(this.row, this.col);
        console.log('renderExcel', this.sheetData);
        const startTime = performance.now()
        this.$refs.luckySheet.updataSheet(this.sheetData)
        const endTime = performance.now();
        this.excelData += `渲染耗时：${((endTime - startTime) / 1000).toFixed(2)}s`

      },
      async handleFileChange(event) {
        this.excelData = null;
        this.file = event.target.files[0];
        console.log('this.file: ', this.file);
        if (this.file) {
          console.log('this.file: ', this.file);
          this.excelData = '格式化数据中...';
          const startTime = performance.now()
          const { exportJson, luckysheetfile } = await getFormatterExcelData(this.file);
          console.log('luckysheetfile: ', luckysheetfile);
          console.log('exportJson: ', exportJson);

          const endTime = performance.now();
          this.excelData = `转换耗时：${((endTime - startTime) / 1000).toFixed(2)}s`;
          this.sheetData = exportJson;
          console.log('sheetData: ', this.sheetData);

        }
      },
      clear() {
        this.pageNum = 1;
        this.$refs.luckySheet.clearAllCell()
      },
      toJson() {
        const jsonData = this.$refs.luckySheet.toJson();
        console.log('jsonData', jsonData);
      },
      batchesRender() {
        let data = this.getOption();
        let pageData = data.sheets;
        data.sheets = getPageData(pageData, this.pageSize * this.col, this.pageNum)
        this.pageNum++
        console.log('sheetData', this.sheetData);
        console.log('batchesRender', data);

        this.$refs.luckySheet.lazyLoadAndRefresh(data, 2);

      },
      refresh() {
        console.log('excelJson', excelJson);
        // this.$refs.luckySheet.refresh(mockData);
        this.sheetData = getMockData(this.row, this.col);
        console.log('renderExcel', this.sheetData);
        const startTime = performance.now()
        // this.$refs.luckySheet.updataSheet(this.sheetData)
        this.$refs.luckySheet.updataSheet(simpleData1)
      },
      handleScroll() {
        console.log("handleScroll");
      }
    },

    mounted() {
      // window.addEventListener("click", () => console.log('ssscroll'));
      // window.addEventListener("resize", () => console.log('onresize'));
      // window.addEventListener("scroll", () => console.log('scroll'));

    },
  }
</script>

<style>
  #mySheet {
    width: 100%;
    height: 600px;

  }

  .wrapper {
    display: flex;
    margin-top: 20px;
    background-color: gainsboro;
    height: 200px;
    padding: 10px;

  }

  .option {
    width: 450px;
    border-right: 1px solid gray;
    margin-right: 20px;

  }

  button {
    margin: 5px;
  }

  .pannel {
    flex: 1;
    height: 150px;
    overflow: auto;
  }
</style>