export const getMockData = (row, col) => {
  const result = [];

  for (let j = 0; j < +row + 1; j++) {
    for (let i = 0; i < +col; i++) {
      if (j === 0) {
        result.push({
          r: j,
          c: i,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  bg: "#000000",
                  bl: 0,
                  cl: 0,
                  fc: "blue",
                  v: "header"
                }
              ]
            },
            bg: "#ff0000",
            fs: 10,
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        });
      } else {
        result.push({
          r: j,
          c: i,
          v: {
            v: "测试数据",
            ct: { fa: "@", t: "s" },
            m: "测试实打实打算"
          }
        });
      }
    }
  }
  console.log("result", result);
  return result;
};

export const getPageData = (data, rowsPerPage, page) => {
  const startIndex = (page - 1) * rowsPerPage;
  const endIndex = Math.min(startIndex + rowsPerPage, data[0].celldata.length);
  data[0].celldata = data[0].celldata.slice(startIndex, endIndex);
  return data;
};
