export const mockData = [
  {
    // 列
    excelHeader: [
      { header: "Id", key: "id", width: 10 },
      { header: "Name", key: "name", width: 32 },
      { header: "D.O.B.", key: "dob", width: 10, outlineLevel: 1 }
    ],
    // 行
    excelData: [
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbaraw", dob: new Date() },
      { id: 8, name: "Barbara1", dob: new Date() },
      { id: 6, name: "Barbare1", dob: new Date() },
      { id: 7, name: "Barbarea", dob: new Date() },
      { id: 8, name: "Barbarae", dob: new Date() },
      { id: 6, name: "Barbarae1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbaera", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 6, name: "ddddd", dob: new Date() },
      { id: 7, name: "dddddddd", dob: new Date() },
      { id: 8, name: "ddddddddddddddddddddddddddd", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "aaaaaaaaaaaaaaaaaaaaaaaa", dob: new Date() },
      { id: 7, name: "dddddddd", dob: new Date() },
      { id: 8, name: "ddddddddddddddddddddddddddd", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "111111111111111111111111111", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "Barbara1", dob: new Date() },
      { id: 7, name: "Barbara", dob: new Date() },
      { id: 8, name: "Barbara", dob: new Date() },
      { id: 6, name: "hdrerer", dob: new Date() }
    ]
  }
];

export const excelJson = {
  info: {
    name: "test (6).xlsx",
    creator: "Unknown",
    lastmodifiedby: "Unknown",
    createdTime: "2023-08-16T01:00:47Z",
    modifiedTime: "2023-08-16T01:00:47Z",
    company: "",
    appversion: "16.0300"
  },
  sheets: [
    {
      name: "Sheet1",
      config: {},
      index: "1",
      status: "0",
      order: "0",
      zoomRatio: 1,
      showGridLines: "1",
      defaultColWidth: 72,
      defaultRowHeight: 20,
      celldata: [
        {
          r: 0,
          c: 0,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "微软雅黑",
                  fc: "#000000",
                  fs: 10,
                  v: "Id"
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 0,
          c: 1,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "微软雅黑",
                  fc: "#000000",
                  fs: 10,
                  v: "Name"
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 0,
          c: 2,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "微软雅黑",
                  fc: "#000000",
                  fs: 10,
                  v: "D.O.B."
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 1,
          c: 0,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: null,
                  fc: "#000000",
                  fs: 10,
                  v: ""
                },
                {
                  ff: "微软雅黑",
                  v: "6",
                  fc: "#000000",
                  fs: 10
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 1,
          c: 1,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "微软雅黑",
                  fc: "#000000",
                  fs: 10,
                  v: "Barbara"
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 1,
          c: 2,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "Calibri",
                  fc: "#000000",
                  fs: 11,
                  v: "45153.068930925925"
                }
              ]
            },
            fs: 11,
            fc: "#000000",
            ff: "Calibri",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 2,
          c: 0,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "宋体",
                  fc: "#000000",
                  fs: 10,
                  v: "哈哈"
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 2,
          c: 1,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "宋体",
                  fc: "#000000",
                  fs: 10,
                  v: "方法"
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 2,
          c: 2,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: null,
                  fc: "#00ff00",
                  fs: 10,
                  v: ""
                },
                {
                  ff: "宋体",
                  v: "是",
                  fc: "#00ff00",
                  fs: 10
                }
              ]
            },
            fs: 10,
            fc: "#00ff00",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 3,
          c: 0,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "宋体",
                  fc: "#000000",
                  fs: 10,
                  v: "得到"
                }
              ]
            },
            bg: "#38761d",
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 3,
          c: 1,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: null,
                  fc: "#000000",
                  fs: 10,
                  v: ""
                },
                {
                  ff: "宋体",
                  v: "的",
                  fc: "#000000",
                  fs: 10
                }
              ]
            },
            fs: 10,
            fc: "#000000",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        },
        {
          r: 3,
          c: 2,
          v: {
            ct: {
              fa: "General",
              t: "inlineStr",
              s: [
                {
                  ff: "宋体",
                  fc: "#e06666",
                  fs: 10,
                  v: "水水"
                }
              ]
            },
            fs: 10,
            fc: "#e06666",
            ff: "微软雅黑",
            ht: 1,
            vt: 1,
            tb: 1
          }
        }
      ],
      calcChain: []
    }
  ]
};
