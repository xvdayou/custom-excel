import FileSaver from "file-saver";
import * as le from "luckyexcel";
import Excel from "exceljs";

let setMerge = function(luckyMerge = {}, worksheet) {
  const mergearr = Object.values(luckyMerge);
  mergearr.forEach(function(elem) {
    // elem格式：{r: 0, c: 0, rs: 1, cs: 2}
    // 按开始行，开始列，结束行，结束列合并（相当于 K10:M12）
    worksheet.mergeCells(
      elem.r + 1,
      elem.c + 1,
      elem.r + elem.rs,
      elem.c + elem.cs
    );
  });
};

let setBorder = function(luckyBorderInfo, worksheet) {
  if (!Array.isArray(luckyBorderInfo)) return;
  // console.log('luckyBorderInfo', luckyBorderInfo)
  luckyBorderInfo.forEach(function(elem) {
    // 现在只兼容到borderType 为range的情况
    // console.log('ele', elem)
    if (elem.rangeType === "range") {
      const border = borderConvert(elem.borderType, elem.style, elem.color);
      const rang = elem.range[0];
      // console.log('range', rang)
      const row = rang.row;
      const column = rang.column;
      for (let i = row[0] + 1; i < row[1] + 2; i++) {
        for (let y = column[0] + 1; y < column[1] + 2; y++) {
          worksheet.getCell(i, y).border = border;
        }
      }
    }
    if (elem.rangeType === "cell") {
      // col_index: 2
      // row_index: 1
      // b: {
      //   color: '#d0d4e3'
      //   style: 1
      // }
      const { col_index, row_index } = elem.value;
      const borderData = Object.assign({}, elem.value);
      delete borderData.col_index;
      delete borderData.row_index;
      const border = addborderToCell(borderData, row_index, col_index);
      // console.log('bordre', border, borderData)
      worksheet.getCell(row_index + 1, col_index + 1).border = border;
    }
    // console.log(rang.column_focus + 1, rang.row_focus + 1)
    // worksheet.getCell(rang.row_focus + 1, rang.column_focus + 1).border = border
  });
};
let setStyleAndValue = function(cellArr, worksheet) {
  if (!Array.isArray(cellArr)) return;
  cellArr.forEach(function(row, rowid) {
    row.every(function(cell, columnid) {
      if (!cell) return true;
      const fill = fillConvert(cell.bg);

      const font = fontConvert(
        cell.ff,
        cell.fc,
        cell.bl,
        cell.it,
        cell.fs,
        cell.cl,
        cell.ul
      );
      const alignment = alignmentConvert(cell.vt, cell.ht, cell.tb, cell.tr);
      let value = "";

      if (cell.f) {
        value = { formula: cell.f, result: cell.v };
      } else if (!cell.v && cell.ct && cell.ct.s) {
        // xls转为xlsx之后，内部存在不同的格式，都会进到富文本里，即值不存在与cell.v，而是存在于cell.ct.s之后
        // value = cell.ct.s[0].v
        cell.ct.s.forEach(arr => {
          value += arr.v;
        });
      } else {
        value = cell.v;
      }
      //  style 填入到_value中可以实现填充色
      const letter = createCellPos(columnid);
      const target = worksheet.getCell(letter + (rowid + 1));
      // console.log('1233', letter + (rowid + 1))
      for (const key in fill) {
        target.fill = fill;
        console.log(key);
        break;
      }
      target.font = font;
      target.alignment = alignment;
      target.value = value;

      return true;
    });
  });
};

let setImages = function(imagesArr, worksheet, workbook) {
  if (typeof imagesArr !== "object") return;
  for (const key in imagesArr) {
    // console.log(imagesArr[key]);
    // 通过 base64  将图像添加到工作簿
    const myBase64Image = imagesArr[key].src;
    // 开始行 开始列 结束行 结束列
    const start = {
      col: imagesArr[key].fromCol,
      row: imagesArr[key].fromRow
    };
    const end = { col: imagesArr[key].toCol, row: imagesArr[key].toRow };
    const imageId = workbook.addImage({
      base64: myBase64Image,
      extension: "png"
    });
    worksheet.addImage(imageId, {
      tl: start,
      br: end,
      editAs: "oneCell"
    });
  }
};

const fillConvert = function(bg) {
  if (!bg) {
    return {};
  }
  // const bgc = bg.replace('#', '')
  const fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: bg.replace("#", "") }
  };
  return fill;
};

const fontConvert = function(
  ff = 0,
  fc = "#000000",
  bl = 0,
  it = 0,
  fs = 10,
  cl = 0,
  ul = 0
) {
  // luckysheet：ff(样式), fc(颜色), bl(粗体), it(斜体), fs(大小), cl(删除线), ul(下划线)
  const luckyToExcel = {
    0: "微软雅黑",
    1: "宋体（Song）",
    2: "黑体（ST Heiti）",
    3: "楷体（ST Kaiti）",
    4: "仿宋（ST FangSong）",
    5: "新宋体（ST Song）",
    6: "华文新魏",
    7: "华文行楷",
    8: "华文隶书",
    9: "Arial",
    10: "Times New Roman ",
    11: "Tahoma ",
    12: "Verdana",
    num2bl: function(num) {
      return num !== 0;
    }
  };
  // 出现Bug，导入的时候ff为luckyToExcel的val

  const font = {
    name: typeof ff === "number" ? luckyToExcel[ff] : ff,
    family: 1,
    size: fs,
    color: { argb: fc.replace("#", "") },
    bold: luckyToExcel.num2bl(bl),
    italic: luckyToExcel.num2bl(it),
    underline: luckyToExcel.num2bl(ul),
    strike: luckyToExcel.num2bl(cl)
  };

  return font;
};

const alignmentConvert = function(
  vt = "default",
  ht = "default",
  tb = "default",
  tr = "default"
) {
  // luckysheet:vt(垂直), ht(水平), tb(换行), tr(旋转)
  const luckyToExcel = {
    vertical: {
      0: "middle",
      1: "top",
      2: "bottom",
      default: "top"
    },
    horizontal: {
      0: "center",
      1: "left",
      2: "right",
      default: "left"
    },
    wrapText: {
      0: false,
      1: false,
      2: true,
      default: false
    },
    textRotation: {
      0: 0,
      1: 45,
      2: -45,
      3: "vertical",
      4: 90,
      5: -90,
      default: 0
    }
  };

  const alignment = {
    vertical: luckyToExcel.vertical[vt],
    horizontal: luckyToExcel.horizontal[ht],
    wrapText: luckyToExcel.wrapText[tb],
    textRotation: luckyToExcel.textRotation[tr]
  };
  return alignment;
};

const borderConvert = function(borderType, style = 1, color = "#000") {
  // 对应luckysheet的config中borderinfo的的参数
  if (!borderType) {
    return {};
  }
  const luckyToExcel = {
    type: {
      "border-all": "all",
      "border-top": "top",
      "border-right": "right",
      "border-bottom": "bottom",
      "border-left": "left"
    },
    style: {
      0: "none",
      1: "thin",
      2: "hair",
      3: "dotted",
      4: "dashDot", // 'Dashed',
      5: "dashDot",
      6: "dashDotDot",
      7: "double",
      8: "medium",
      9: "mediumDashed",
      10: "mediumDashDot",
      11: "mediumDashDotDot",
      12: "slantDashDot",
      13: "thick"
    }
  };
  const template = {
    style: luckyToExcel.style[style],
    color: { argb: color.replace("#", "") }
  };
  const border = {};
  if (luckyToExcel.type[borderType] === "all") {
    border["top"] = template;
    border["right"] = template;
    border["bottom"] = template;
    border["left"] = template;
  } else {
    border[luckyToExcel.type[borderType]] = template;
  }
  // console.log('border', border)
  return border;
};

function addborderToCell(borders, rowIndex, colIndex) {
  const border = {};
  const luckyExcel = {
    type: {
      l: "left",
      r: "right",
      b: "bottom",
      t: "top"
    },
    style: {
      0: "none",
      1: "thin",
      2: "hair",
      3: "dotted",
      4: "dashDot", // 'Dashed',
      5: "dashDot",
      6: "dashDotDot",
      7: "double",
      8: "medium",
      9: "mediumDashed",
      10: "mediumDashDot",
      11: "mediumDashDotDot",
      12: "slantDashDot",
      13: "thick"
    }
  };
  // console.log('borders', borders)
  for (const bor in borders) {
    // console.log(bor)
    if (borders[bor].color.indexOf("rgb") === -1) {
      border[luckyExcel.type[bor]] = {
        style: luckyExcel.style[borders[bor].style],
        color: { argb: borders[bor].color.replace("#", "") }
      };
    } else {
      border[luckyExcel.type[bor]] = {
        style: luckyExcel.style[borders[bor].style],
        color: { argb: borders[bor].color }
      };
    }
  }

  return border;
}

function createCellPos(n) {
  const ordA = "A".charCodeAt(0);

  const ordZ = "Z".charCodeAt(0);
  const len = ordZ - ordA + 1;
  let s = "";
  while (n >= 0) {
    s = String.fromCharCode((n % len) + ordA) + s;

    n = Math.floor(n / len) - 1;
  }
  return s;
}
/**
 * 下载excel文件
 * @param {*} luckysheet luckyspeet的data数据
 * @param {*} filename 下载名称
 */
export const exportExcel = async (luckysheet, filename) => {
  const luckysheetData = luckysheet.getAllSheets();
  // 1.创建工作簿，可以为工作簿添加属性
  const workbook = new Excel.Workbook();
  // 2.创建表格，第二个参数可以配置创建什么样的工作表
  luckysheetData.forEach(function(table) {
    if (table.data.length === 0) return true;
    const worksheet = workbook.addWorksheet(table.name);
    const merge = (table.config && table.config.merge) || {};
    const borderInfo = (table.config && table.config.borderInfo) || {};
    // 3.设置单元格合并,设置单元格边框,设置单元格样式,设置值,导出图片
    setStyleAndValue(table.data, worksheet);
    setMerge(merge, worksheet);
    setBorder(borderInfo, worksheet);
    setImages(table.images, worksheet, workbook);
    return true;
  });

  // 4.写入 buffer
  const data = await workbook.xlsx.writeBuffer();
  const blob = new Blob([data], {
    type: "application/vnd.ms-excel;charset=utf-8"
  });
  FileSaver.saveAs(blob, `${filename}.xlsx`);
};
/**
 * 获取excel文件对象
 * @param {*} luckysheet luckyspeet的data数据
 * @returns 返回传入接口的file对象
 */
export const getExcelFile = async luckysheet => {
  const luckysheetData = luckysheet.getAllSheets();
  console.log("getExcelFile", luckysheetData);
  // 1.创建工作簿，可以为工作簿添加属性
  const workbook = new Excel.Workbook();
  // 2.创建表格，第二个参数可以配置创建什么样的工作表
  luckysheetData.forEach(function(table) {
    if (table.data.length === 0) return true;
    const worksheet = workbook.addWorksheet(table.name);
    const merge = (table.config && table.config.merge) || {};
    const borderInfo = (table.config && table.config.borderInfo) || {};
    // 3.设置单元格合并,设置单元格边框,设置单元格样式,设置值,导出图片
    setStyleAndValue(table.data, worksheet);
    setMerge(merge, worksheet);
    setBorder(borderInfo, worksheet);
    setImages(table.images, worksheet, workbook);
    return true;
  });
  // 4.写入 buffer
  const data = await workbook.xlsx.writeBuffer();
  const file = new File([data], "xxx.xlsx");
  const params = new FormData();
  params.append("file", file);
  return params;
};
/**
 * 将excel文件导入excel组件
 * @param {*} file 导入的excel文件
 */
export const transformFileToLucky = file => {
  le.transformExcelToLucky(
    file,
    function(exportJson, luckysheetfile) {
      // 获得转化后的表格数据后，使用luckysheet初始化，或者更新已有的luckysheet工作簿
      // 注：luckysheet需要引入依赖包和初始化表格容器才可以使用
      console.log("transformFileToLucky  exportJson: ", exportJson.sheets);
      console.log("transformFileToLucky  luckysheetfile: ", luckysheetfile);

      window.luckysheet.create({
        container: "luckysheet", // luckysheet is the container id
        showinfobar: false,
        data: exportJson.sheets
      });
    },
    function(err) {
      console.log("Import failed. Is your fail a valid xlsx?");
    }
  );
};
/**
 * 将表格数据回显到excel中
 * @param {*} header 表格头部数组
 * @param {*} tableData 表格数据
 */
export const tableToExcel = async (header, tableData) => {
  // 创建工作簿
  const workbook = new Excel.Workbook();
  // 添加工作表
  const worksheet = workbook.addWorksheet("Sheet1");
  // 添加列标题并定义列键
  worksheet.columns = [...header];
  // 添加多行数据
  worksheet.addRows([...tableData]);
  // 写入 buffer
  const buffer = await workbook.xlsx.writeBuffer();
  const file = new File([buffer], "xxx.xlsx");
  transformFileToLucky(file);
};

export const getFormatterExcelData = file => {
  // 先确保获取到了xlsx文件file，再使用全局方法window.LuckyExcel转化

  return new Promise((resolve, reject) => {
    le.transformExcelToLucky(
      file,
      function(exportJson, luckysheetfile) {
        // 获得转化后的表格数据后，使用luckysheet初始化，或者更新已有的luckysheet工作簿
        // 注：luckysheet需要引入依赖包和初始化表格容器才可以使

        if (exportJson && luckysheetfile) {
          // return { exportJson, luckysheetfile };
          // console.log(object);

          resolve({ exportJson, luckysheetfile });
        }
      },
      function(err) {
        // logger.error("Import failed. Is your fail a valid xlsx?");
        reject(err);
      }
    );
  });
};

export function initSheet(option) {
  console.log("initSheet", option);
  window.luckysheet.create({ ...option });
}

export function renderExcel(option = {}) {
  console.log("renderExcel: ", option);

  window.luckysheet.create(option);
}

export function updataSheet(options) {
  console.log("updataSheet", options);
  window.luckysheet.updataSheet(options);
  // window.luckysheet.refresh(options);
}
export function toJson() {
  return window.luckysheet.toJson();
}

/**
 * 分批渲染
 * @param {*} data
 * @param {*} rowNum 一次渲染多少行
 */
export function batchesRender(data, rowNum = 1) {
  // let testData = new Array(50).fill(1);

  // testData.forEach((item, index) => {
  //   luckysheet.setCellValue(index, index, index + 1);
  // });
  // return;

  data.forEach((item, index) => {
    console.log("item", data[index]);
    // window.luckysheet.setCellValue()
    const { excelHeader, excelData } = item;
    dataRendSheet(excelHeader, excelData);
  });
}

function dataRendSheet(excelHeader, excelData) {
  console.log("dataRendSheet", excelHeader, excelData);
  //回显表格表头，第一行
  if (excelHeader.length > 0) {
    excelHeader.forEach((item1, index1) => {
      luckysheet.setCellValue(0, index1, item1.header);
      //普通回显数据
      excelData.forEach((item2, index2) => {
        var row = index2 + 1;
        luckysheet.setCellValue(row, index1, item2.name);
      });
    });
  }
}

export function refresh(sheetData) {
  // 渲染工作表的单元格数据
  const celldata = sheetData.sheets[0].celldata;
  console.log("cellData", celldata);
  celldata.forEach(cell => {
    const { r, c, v } = cell;
    if (v.hasOwnProperty("v")) {
      // 如果单元格数据包含 "v" 属性，则使用 setCellValue 设置单元格内容;
      window.luckysheet.setCellValue(r, c, v.v);
    }
    // 如果您还有其他样式信息，可以在此处使用 Luckysheet 提供的 API 方法设置
  });
}

/**
 *
 * @param {*} sheetData
 * @param {*} batchSize 批量渲染的数量
 */
export function lazyLoadAndRefresh(sheetData, batchSize = 8) {
  const sheets = sheetData.sheets;

  let rowIndex = 0; // 当前加载的行索引
  let sheetIndex = 0; // 当前工作表索引

  function loadBatch() {
    const celldata = sheets[sheetIndex].celldata;

    for (let i = 0; i < batchSize && rowIndex < celldata.length; i++) {
      const cell = celldata[rowIndex];
      const { r, c, v } = cell;
      const value = getValueFromCell(v);
      window.luckysheet.setCellValue(r, c, value, sheetIndex);

      rowIndex++;
    }

    if (rowIndex < celldata.length) {
      requestAnimationFrame(loadBatch);
    } else {
      rowIndex = 0;
      sheetIndex++;

      if (sheetIndex < sheets.length) {
        requestAnimationFrame(loadBatch);
      }
    }
  }

  loadBatch();
}

function getValueFromCell(cellValue) {
  if (cellValue.hasOwnProperty("v")) {
    return cellValue.v;
  } else if (cellValue.hasOwnProperty("ct")) {
    const inlineStr = cellValue.ct.t === "inlineStr";
    if (inlineStr) {
      return cellValue.ct.s.map(style => style.v).join("");
    }
  }
  return "";
}

export function clearAllCell() {
  const luckysheet = window.luckysheet;
  // 获取当前工作表对象
  const activeSheet = luckysheet.getActiveSheet();

  // 清空整个工作表的内容
  activeSheet.data = [];

  // 刷新工作表
  luckysheet.refresh();
}
