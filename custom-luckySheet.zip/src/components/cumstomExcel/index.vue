<template>
  <div id="luckysheet" class="luckysheet-content" ref="luckysheetContainer" @scroll="handleScroll"></div>
</template>

<script>
  import { initalOption } from './initalOption.js'
  import {
    initSheet,
    getExcelFile,
    tableToExcel,
    transformFileToLucky,
    exportExcel,
    getFormatterExcelData,
    renderExcel,
    updataSheet,
    toJson,
    batchesRender,
    refresh,
    lazyLoadAndRefresh,
    clearAllCell
  } from './action'
  export default {
    name: "CustomExcel",
    props: {
      sheetData: {},
      config: {
        type: Object
      }
    },

    data() {
      return {
        option: {
          container: "luckysheet",
          title: '',
          lang: 'zh'
        },

      };
    },
    computed: {
      registeredEvents() {
        return this._events;
      },

      computedHook() {
        let registered = {};
        for (const key in this.hook) {
          if (key in this.$listeners) {
            registered[key] = this.hook[key];
          }
        }
        console.log('registered', registered);
        return registered;
      },
    },
    created() {
      this.mergeOption();
    },
    mounted() {
      initSheet(this.option)
      const luckysheetContainer = this.$refs.luckysheetContainer;
      console.log('luckysheetContainer: ', luckysheetContainer);
      luckysheetContainer.addEventListener("scroll", this.handleScroll);
      window.addEventListener("scroll", this.handleScroll);
    },
    methods: {
      mergeOption() {
        this.option = { ...this.option, ...this.config };
        this.option.hook = {
          workbookCreateBefore: this.workbookCreateBefore,
          workbookCreateAfter: this.workbookCreateAfter,
          workbookDestroyBefore: this.workbookDestroyBefore,
          workbookDestroyAfter: this.workbookDestroyAfter,
        }
      },
      getInstance() {
        return luckysheet
      },

      async handleCellMousedown() {
        const res = await getExcelFile(luckysheet);
        console.log('handleData', res);
      },
      exportExcel() {
        exportExcel(luckysheet, this.opiton.info.name)
      },
      tableToExcel() {
        tableToExcel(this.sheetData.excelHeader, this.sheetData.excelData);
      },
      renderExcel(data) {
        window.luckysheet.destroy()
        const { info, sheets } = data;
        const option = {
          ...this.option,
          ...info,
          row: info.count + 10, //根据总行数多增加10行
          data: sheets
        }
        console.log('option', option);
        renderExcel(option)

      },
      updataSheet(data) {
        this.option.data = data;
        updataSheet(this.option)
      },
      clearAllCell() {
        let option = {
          container: "luckysheet",
          title: '',
          lang: 'zh',
          row: this.option.row,
          data: [
            {
              name: 'sheet',
              celldata: []
            }
          ]
        }

        initSheet(option)

        // clearAllCell()
      },
      toJson() {
        return toJson()
      },

      transToData() {
        let transToCellData = luckysheet.transToCellData([this.sheetData])
        console.log('transToCellData: ', transToCellData);
        let transToData = luckysheet.transToData([...this.sheetData])
        console.log('transToData: ', transToData);
      },
      batchesRender(data) {
        batchesRender(data)
      },
      lazyLoadAndRefresh(data, batchNum) {
        lazyLoadAndRefresh(data, batchNum)
      },

      handleScroll(event) {
        // 在这里处理滚动条事件逻辑
        console.log("Scrolled:", event.target.scrollTop);
      },


      // 事件
      workbookCreateBefore(book) {
        console.log('workbookCreateBefore: ');
        this.$emit("workbookCreateBefore", book);
      },

      workbookCreateAfter(book) {
        console.log('workbookCreateAfter');
        this.$emit("workbookCreateAfter", book);
      },

      workbookDestroyBefore(book) {
        this.$emit("workbookDestroyBefore", book);
      },

      workbookDestroyAfter(book) {
        this.$emit("workbookDestroyAfter", book);
      },

    },
    beforeDestroy() {
      // const luckysheetContainer = this.$refs.luckysheetContainer;
      // luckysheetContainer.removeEventListener("scroll", this.handleScroll);
    },

  };
</script>
<style lang="css" scoped>
  .luckysheet-content {
    width: 100%;
    height: 100%;
    overflow: auto;
  }
</style>